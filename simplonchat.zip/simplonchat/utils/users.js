const users = [];

//  Ajouter le user a la room
function userJoin(id, username, room) {
  const user = { id, username, room };

  users.push(user);

  return user;
}

// Retourne l'utilisateur actuel par l'id
function getCurrentUser(id) {
  return users.find(user => user.id === id);
}

// l'utilisateur quitte la room
function userLeave(id) {
  const index = users.findIndex(user => user.id === id);

  if (index !== -1) {
    return users.splice(index, 1)[0];
  }
}

// retrourne les utilisateurs dans le room
function getRoomUsers(room) {
  return users.filter(user => user.room === room);
}

module.exports = {
  userJoin,
  getCurrentUser,
  userLeave,
  getRoomUsers
};
