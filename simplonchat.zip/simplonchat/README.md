# Simplonchatapp
VanillaJS, SocketIO, Node
## Usage
```
npm install
npm run dev

localhost:3000